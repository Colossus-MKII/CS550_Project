CS550 proposal using the official ACML 2026 class.

Upload this ZIP to Overleaf and set proposal.tex as the main document,
or compile with tectonic --untrusted proposal.tex.
Standard TeX dependencies come from the compiler/TeX distribution.
The class is unmodified. Course metadata replaces proceedings metadata.
See TEMPLATE-PROVENANCE.md and LICENSE-LPPL-1.3c.txt.

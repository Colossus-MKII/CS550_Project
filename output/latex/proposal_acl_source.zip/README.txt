CS550 proposal using the exact user-supplied ACL conference template.

Upload this ZIP to Overleaf and set proposal.tex as the main document,
or compile with tectonic --untrusted proposal.tex.
Standard TeX dependencies come from the compiler/TeX distribution.
acl.sty and acl_natbib.bst are unmodified from the supplied ZIP.
See TEMPLATE-PROVENANCE.md and LICENSE-LPPL-1.3c.txt.
